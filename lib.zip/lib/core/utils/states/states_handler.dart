import 'dart:developer';
import 'package:dartz/dartz.dart';
import 'package:pharma_x/core/errors/failures.dart';
import 'package:pharma_x/core/utils/handle_failures.dart';

mixin StatesHandler {
  ProviderStates failureOrDataToState<T>(
    Either<Failure, T> either, {
    bool handleF = true,
    bool handleS = false,
  }) {
    return either.fold(
      (failure) {
        log(failure.message);
        handleFailure(failure);
        return ErrorState(failure: failure);
      },
      (data) {
        return DataState<T>(data: data);
      },
    );
  }
}

abstract class ProviderStates {
  const ProviderStates();
}

class ErrorState extends ProviderStates {
  final Failure failure;

  const ErrorState({required this.failure});
}

class DataState<T> extends ProviderStates {
  final T data;

  DataState({required this.data});
}
