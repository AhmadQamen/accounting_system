import 'package:accounting_system/core/configs/unset.dart';
import 'package:accounting_system/core/models/model_parsers.dart';

abstract interface class CashListItem {}

class Cashbox implements CashListItem {
  final String? id;
  final String? entityId;
  final String name;
  final int currentBalanceMinor;
  final DateTime? createdAt;
  final DateTime? updatedAt;
  final DateTime? deletedAt;
  final int version;
  const Cashbox({
    this.id,
    this.entityId,
    required this.name,
    this.currentBalanceMinor = 0,
    this.createdAt,
    this.updatedAt,
    this.deletedAt,
    this.version = 1,
  });
  factory Cashbox.fromSql(Map<String, Object?> r) => Cashbox(
    id: stringOrNull(r['id']),
    entityId: stringOrNull(r['entity_id']),
    name: r['name']?.toString() ?? '',
    currentBalanceMinor: intValue(r['current_balance_minor']),
    createdAt: parseDate(r['created_at']),
    updatedAt: parseDate(r['updated_at']),
    deletedAt: parseDate(r['deleted_at']),
    version: intValue(r['version'], 1),
  );
  factory Cashbox.fromJson(Map<String, dynamic> r) => Cashbox(
    id: stringOrNull(r['id']),
    entityId: stringOrNull(r['entityId'] ?? r['entity_id']),
    name: r['name']?.toString() ?? '',
    currentBalanceMinor: intValue(
      r['currentBalanceMinor'] ?? r['current_balance_minor'],
    ),
    createdAt: parseDate(r['createdAt'] ?? r['created_at']),
    updatedAt: parseDate(r['updatedAt'] ?? r['updated_at']),
    deletedAt: parseDate(r['deletedAt'] ?? r['deleted_at']),
    version: intValue(r['version'], 1),
  );
  Map<String, Object?> toSql() => {
    if (id != null) 'id': id,
    'entity_id': entityId,
    'name': name,
    'current_balance_minor': currentBalanceMinor,
    'created_at': isoUtc(createdAt),
    'updated_at': isoUtc(updatedAt),
    'deleted_at': isoUtc(deletedAt),
    'version': version,
  };
  Map<String, dynamic> toJson() => {
    if (id != null) 'id': id,
    'entityId': entityId,
    'name': name,
    'currentBalanceMinor': currentBalanceMinor,
    'createdAt': isoUtc(createdAt),
    'updatedAt': isoUtc(updatedAt),
    'deletedAt': isoUtc(deletedAt),
    'version': version,
  };
  Cashbox copyWith({
    Object? id = unset,
    Object? entityId = unset,
    Object? name = unset,
    Object? currentBalanceMinor = unset,
    Object? createdAt = unset,
    Object? updatedAt = unset,
    Object? deletedAt = unset,
    Object? version = unset,
  }) => Cashbox(
    id: id is Unset ? this.id : id as String?,
    entityId: entityId is Unset ? this.entityId : entityId as String?,
    name: name is Unset ? this.name : name as String,
    currentBalanceMinor:
        currentBalanceMinor is Unset
            ? this.currentBalanceMinor
            : currentBalanceMinor as int,
    createdAt: createdAt is Unset ? this.createdAt : createdAt as DateTime?,
    updatedAt: updatedAt is Unset ? this.updatedAt : updatedAt as DateTime?,
    deletedAt: deletedAt is Unset ? this.deletedAt : deletedAt as DateTime?,
    version: version is Unset ? this.version : version as int,
  );
}

class Expense implements CashListItem {
  final String? id;
  final String? entityId;
  final String? financialYearId;
  final String expenseNumber;
  final String cashboxId;
  final String? cashboxName;
  final int amountMinor;
  final String status;
  final String? note;
  final DateTime? occurredAt;
  final DateTime? postedAt;
  final DateTime? voidedAt;
  const Expense({
    this.id,
    this.entityId,
    this.financialYearId,
    required this.expenseNumber,
    required this.cashboxId,
    this.cashboxName,
    this.amountMinor = 0,
    this.status = 'draft',
    this.note,
    this.occurredAt,
    this.postedAt,
    this.voidedAt,
  });
  factory Expense.fromSql(Map<String, Object?> r) => Expense(
    id: stringOrNull(r['id']),
    entityId: stringOrNull(r['entity_id']),
    financialYearId: stringOrNull(r['financial_year_id']),
    expenseNumber: r['expense_number']?.toString() ?? '',
    cashboxId: r['cashbox_id']?.toString() ?? '',
    cashboxName: stringOrNull(r['cashbox_name']),
    amountMinor: intValue(r['amount_minor']),
    status: r['status']?.toString() ?? 'draft',
    note: stringOrNull(r['note']),
    occurredAt: parseDate(r['occurred_at']),
    postedAt: parseDate(r['posted_at']),
    voidedAt: parseDate(r['voided_at']),
  );
  factory Expense.fromJson(Map<String, dynamic> r) => Expense(
    id: stringOrNull(r['id']),
    entityId: stringOrNull(r['entityId'] ?? r['entity_id']),
    financialYearId: stringOrNull(
      r['financialYearId'] ?? r['financial_year_id'],
    ),
    expenseNumber:
        (r['expenseNumber'] ?? r['expense_number'])?.toString() ?? '',
    cashboxId: (r['cashboxId'] ?? r['cashbox_id'])?.toString() ?? '',
    cashboxName: stringOrNull(r['cashboxName'] ?? r['cashbox_name']),
    amountMinor: intValue(r['amountMinor'] ?? r['amount_minor']),
    status: r['status']?.toString() ?? 'draft',
    note: stringOrNull(r['note']),
    occurredAt: parseDate(r['occurredAt'] ?? r['occurred_at']),
    postedAt: parseDate(r['postedAt'] ?? r['posted_at']),
    voidedAt: parseDate(r['voidedAt'] ?? r['voided_at']),
  );
  Map<String, Object?> toSql() => {
    if (id != null) 'id': id,
    'entity_id': entityId,
    'financial_year_id': financialYearId,
    'expense_number': expenseNumber,
    'cashbox_id': cashboxId,
    'amount_minor': amountMinor,
    'status': status,
    'note': note,
    'occurred_at': isoUtc(occurredAt),
    'posted_at': isoUtc(postedAt),
    'voided_at': isoUtc(voidedAt),
  };
  Map<String, dynamic> toJson() => {
    if (id != null) 'id': id,
    'entityId': entityId,
    'financialYearId': financialYearId,
    'expenseNumber': expenseNumber,
    'cashboxId': cashboxId,
    'cashboxName': cashboxName,
    'amountMinor': amountMinor,
    'status': status,
    'note': note,
    'occurredAt': isoUtc(occurredAt),
    'postedAt': isoUtc(postedAt),
    'voidedAt': isoUtc(voidedAt),
  };
  Expense copyWith({
    Object? id = unset,
    Object? entityId = unset,
    Object? financialYearId = unset,
    Object? expenseNumber = unset,
    Object? cashboxId = unset,
    Object? cashboxName = unset,
    Object? amountMinor = unset,
    Object? status = unset,
    Object? note = unset,
    Object? occurredAt = unset,
    Object? postedAt = unset,
    Object? voidedAt = unset,
  }) => Expense(
    id: id is Unset ? this.id : id as String?,
    entityId: entityId is Unset ? this.entityId : entityId as String?,
    financialYearId:
        financialYearId is Unset
            ? this.financialYearId
            : financialYearId as String?,
    expenseNumber:
        expenseNumber is Unset ? this.expenseNumber : expenseNumber as String,
    cashboxId: cashboxId is Unset ? this.cashboxId : cashboxId as String,
    cashboxName:
        cashboxName is Unset ? this.cashboxName : cashboxName as String?,
    amountMinor: amountMinor is Unset ? this.amountMinor : amountMinor as int,
    status: status is Unset ? this.status : status as String,
    note: note is Unset ? this.note : note as String?,
    occurredAt: occurredAt is Unset ? this.occurredAt : occurredAt as DateTime?,
    postedAt: postedAt is Unset ? this.postedAt : postedAt as DateTime?,
    voidedAt: voidedAt is Unset ? this.voidedAt : voidedAt as DateTime?,
  );
}

class CashTransfer implements CashListItem {
  final String? id;
  final String transferNumber;
  final String fromCashboxId;
  final String toCashboxId;
  final String? fromCashboxName;
  final String? toCashboxName;
  final int amountMinor;
  final String status;
  final String? note;
  final DateTime? occurredAt;
  const CashTransfer({
    this.id,
    required this.transferNumber,
    required this.fromCashboxId,
    required this.toCashboxId,
    this.fromCashboxName,
    this.toCashboxName,
    this.amountMinor = 0,
    this.status = 'draft',
    this.note,
    this.occurredAt,
  });
  factory CashTransfer.fromSql(Map<String, Object?> r) => CashTransfer(
    id: stringOrNull(r['id']),
    transferNumber: r['transfer_number']?.toString() ?? '',
    fromCashboxId: r['from_cashbox_id']?.toString() ?? '',
    toCashboxId: r['to_cashbox_id']?.toString() ?? '',
    fromCashboxName: stringOrNull(r['from_cashbox_name']),
    toCashboxName: stringOrNull(r['to_cashbox_name']),
    amountMinor: intValue(r['amount_minor']),
    status: r['status']?.toString() ?? 'draft',
    note: stringOrNull(r['note']),
    occurredAt: parseDate(r['occurred_at']),
  );
  factory CashTransfer.fromJson(Map<String, dynamic> r) => CashTransfer(
    id: stringOrNull(r['id']),
    transferNumber:
        (r['transferNumber'] ?? r['transfer_number'])?.toString() ?? '',
    fromCashboxId:
        (r['fromCashboxId'] ?? r['from_cashbox_id'])?.toString() ?? '',
    toCashboxId: (r['toCashboxId'] ?? r['to_cashbox_id'])?.toString() ?? '',
    fromCashboxName: stringOrNull(
      r['fromCashboxName'] ?? r['from_cashbox_name'],
    ),
    toCashboxName: stringOrNull(r['toCashboxName'] ?? r['to_cashbox_name']),
    amountMinor: intValue(r['amountMinor'] ?? r['amount_minor']),
    status: r['status']?.toString() ?? 'draft',
    note: stringOrNull(r['note']),
    occurredAt: parseDate(r['occurredAt'] ?? r['occurred_at']),
  );
  Map<String, Object?> toSql() => {
    if (id != null) 'id': id,
    'transfer_number': transferNumber,
    'from_cashbox_id': fromCashboxId,
    'to_cashbox_id': toCashboxId,
    'amount_minor': amountMinor,
    'status': status,
    'note': note,
    'occurred_at': isoUtc(occurredAt),
  };
  Map<String, dynamic> toJson() => {
    if (id != null) 'id': id,
    'transferNumber': transferNumber,
    'fromCashboxId': fromCashboxId,
    'toCashboxId': toCashboxId,
    'fromCashboxName': fromCashboxName,
    'toCashboxName': toCashboxName,
    'amountMinor': amountMinor,
    'status': status,
    'note': note,
    'occurredAt': isoUtc(occurredAt),
  };
  CashTransfer copyWith({
    Object? id = unset,
    Object? transferNumber = unset,
    Object? fromCashboxId = unset,
    Object? toCashboxId = unset,
    Object? fromCashboxName = unset,
    Object? toCashboxName = unset,
    Object? amountMinor = unset,
    Object? status = unset,
    Object? note = unset,
    Object? occurredAt = unset,
  }) => CashTransfer(
    id: id is Unset ? this.id : id as String?,
    transferNumber:
        transferNumber is Unset
            ? this.transferNumber
            : transferNumber as String,
    fromCashboxId:
        fromCashboxId is Unset ? this.fromCashboxId : fromCashboxId as String,
    toCashboxId:
        toCashboxId is Unset ? this.toCashboxId : toCashboxId as String,
    fromCashboxName:
        fromCashboxName is Unset
            ? this.fromCashboxName
            : fromCashboxName as String?,
    toCashboxName:
        toCashboxName is Unset ? this.toCashboxName : toCashboxName as String?,
    amountMinor: amountMinor is Unset ? this.amountMinor : amountMinor as int,
    status: status is Unset ? this.status : status as String,
    note: note is Unset ? this.note : note as String?,
    occurredAt: occurredAt is Unset ? this.occurredAt : occurredAt as DateTime?,
  );
}

class CashAdjustment {
  final String? id;
  final String adjustmentNumber;
  final String cashboxId;
  final String? cashboxName;
  final String direction;
  final int amountMinor;
  final String status;
  final String? note;
  final DateTime? occurredAt;
  const CashAdjustment({
    this.id,
    required this.adjustmentNumber,
    required this.cashboxId,
    this.cashboxName,
    required this.direction,
    this.amountMinor = 0,
    this.status = 'draft',
    this.note,
    this.occurredAt,
  });
  factory CashAdjustment.fromSql(Map<String, Object?> r) => CashAdjustment(
    id: stringOrNull(r['id']),
    adjustmentNumber: r['adjustment_number']?.toString() ?? '',
    cashboxId: r['cashbox_id']?.toString() ?? '',
    cashboxName: stringOrNull(r['cashbox_name']),
    direction: r['direction']?.toString() ?? 'in',
    amountMinor: intValue(r['amount_minor']),
    status: r['status']?.toString() ?? 'draft',
    note: stringOrNull(r['note']),
    occurredAt: parseDate(r['occurred_at']),
  );
  factory CashAdjustment.fromJson(Map<String, dynamic> r) => CashAdjustment(
    id: stringOrNull(r['id']),
    adjustmentNumber:
        (r['adjustmentNumber'] ?? r['adjustment_number'])?.toString() ?? '',
    cashboxId: (r['cashboxId'] ?? r['cashbox_id'])?.toString() ?? '',
    cashboxName: stringOrNull(r['cashboxName'] ?? r['cashbox_name']),
    direction: r['direction']?.toString() ?? 'in',
    amountMinor: intValue(r['amountMinor'] ?? r['amount_minor']),
    status: r['status']?.toString() ?? 'draft',
    note: stringOrNull(r['note']),
    occurredAt: parseDate(r['occurredAt'] ?? r['occurred_at']),
  );
  Map<String, Object?> toSql() => {
    if (id != null) 'id': id,
    'adjustment_number': adjustmentNumber,
    'cashbox_id': cashboxId,
    'direction': direction,
    'amount_minor': amountMinor,
    'status': status,
    'note': note,
    'occurred_at': isoUtc(occurredAt),
  };
  Map<String, dynamic> toJson() => {
    if (id != null) 'id': id,
    'adjustmentNumber': adjustmentNumber,
    'cashboxId': cashboxId,
    'cashboxName': cashboxName,
    'direction': direction,
    'amountMinor': amountMinor,
    'status': status,
    'note': note,
    'occurredAt': isoUtc(occurredAt),
  };
  CashAdjustment copyWith({
    Object? id = unset,
    Object? adjustmentNumber = unset,
    Object? cashboxId = unset,
    Object? cashboxName = unset,
    Object? direction = unset,
    Object? amountMinor = unset,
    Object? status = unset,
    Object? note = unset,
    Object? occurredAt = unset,
  }) => CashAdjustment(
    id: id is Unset ? this.id : id as String?,
    adjustmentNumber:
        adjustmentNumber is Unset
            ? this.adjustmentNumber
            : adjustmentNumber as String,
    cashboxId: cashboxId is Unset ? this.cashboxId : cashboxId as String,
    cashboxName:
        cashboxName is Unset ? this.cashboxName : cashboxName as String?,
    direction: direction is Unset ? this.direction : direction as String,
    amountMinor: amountMinor is Unset ? this.amountMinor : amountMinor as int,
    status: status is Unset ? this.status : status as String,
    note: note is Unset ? this.note : note as String?,
    occurredAt: occurredAt is Unset ? this.occurredAt : occurredAt as DateTime?,
  );
}

class CashTransaction implements CashListItem {
  final String? id;
  final String? cashboxId;
  final String? cashboxName;
  final String? partyId;
  final String? partyName;
  final String direction;
  final String kind;
  final int amountMinor;
  final String? note;
  final String? referenceType;
  final String? referenceId;
  final DateTime? occurredAt;
  const CashTransaction({
    this.id,
    this.cashboxId,
    this.cashboxName,
    this.partyId,
    this.partyName,
    this.direction = 'in',
    this.kind = 'other',
    this.amountMinor = 0,
    this.note,
    this.referenceType,
    this.referenceId,
    this.occurredAt,
  });
  factory CashTransaction.fromSql(Map<String, Object?> r) => CashTransaction(
    id: stringOrNull(r['id']),
    cashboxId: stringOrNull(r['cashbox_id']),
    cashboxName: stringOrNull(r['cashbox_name']),
    partyId: stringOrNull(r['party_id']),
    partyName: stringOrNull(r['party_name']),
    direction: r['direction']?.toString() ?? 'in',
    kind: r['kind']?.toString() ?? 'other',
    amountMinor: intValue(r['amount_minor']),
    note: stringOrNull(r['note']),
    referenceType: stringOrNull(r['reference_type']),
    referenceId: stringOrNull(r['reference_id']),
    occurredAt: parseDate(r['occurred_at']),
  );
  factory CashTransaction.fromJson(Map<String, dynamic> r) => CashTransaction(
    id: stringOrNull(r['id']),
    cashboxId: stringOrNull(r['cashboxId'] ?? r['cashbox_id']),
    cashboxName: stringOrNull(r['cashboxName'] ?? r['cashbox_name']),
    partyId: stringOrNull(r['partyId'] ?? r['party_id']),
    partyName: stringOrNull(r['partyName'] ?? r['party_name']),
    direction: r['direction']?.toString() ?? 'in',
    kind: r['kind']?.toString() ?? 'other',
    amountMinor: intValue(r['amountMinor'] ?? r['amount_minor']),
    note: stringOrNull(r['note']),
    referenceType: stringOrNull(r['referenceType'] ?? r['reference_type']),
    referenceId: stringOrNull(r['referenceId'] ?? r['reference_id']),
    occurredAt: parseDate(r['occurredAt'] ?? r['occurred_at']),
  );
  Map<String, Object?> toSql() => {
    if (id != null) 'id': id,
    'cashbox_id': cashboxId,
    'party_id': partyId,
    'direction': direction,
    'kind': kind,
    'amount_minor': amountMinor,
    'note': note,
    'reference_type': referenceType,
    'reference_id': referenceId,
    'occurred_at': isoUtc(occurredAt),
  };
  Map<String, dynamic> toJson() => {
    if (id != null) 'id': id,
    'cashboxId': cashboxId,
    'cashboxName': cashboxName,
    'partyId': partyId,
    'partyName': partyName,
    'direction': direction,
    'kind': kind,
    'amountMinor': amountMinor,
    'note': note,
    'referenceType': referenceType,
    'referenceId': referenceId,
    'occurredAt': isoUtc(occurredAt),
  };
  CashTransaction copyWith({
    Object? id = unset,
    Object? cashboxId = unset,
    Object? cashboxName = unset,
    Object? partyId = unset,
    Object? partyName = unset,
    Object? direction = unset,
    Object? kind = unset,
    Object? amountMinor = unset,
    Object? note = unset,
    Object? referenceType = unset,
    Object? referenceId = unset,
    Object? occurredAt = unset,
  }) => CashTransaction(
    id: id is Unset ? this.id : id as String?,
    cashboxId: cashboxId is Unset ? this.cashboxId : cashboxId as String?,
    cashboxName:
        cashboxName is Unset ? this.cashboxName : cashboxName as String?,
    partyId: partyId is Unset ? this.partyId : partyId as String?,
    partyName: partyName is Unset ? this.partyName : partyName as String?,
    direction: direction is Unset ? this.direction : direction as String,
    kind: kind is Unset ? this.kind : kind as String,
    amountMinor: amountMinor is Unset ? this.amountMinor : amountMinor as int,
    note: note is Unset ? this.note : note as String?,
    referenceType:
        referenceType is Unset ? this.referenceType : referenceType as String?,
    referenceId:
        referenceId is Unset ? this.referenceId : referenceId as String?,
    occurredAt: occurredAt is Unset ? this.occurredAt : occurredAt as DateTime?,
  );
}

class CashSession implements CashListItem {
  final String? id;
  final String cashboxId;
  final String? cashboxName;
  final String status;
  final int openingAmountMinor;
  final int? expectedAmountMinor;
  final int? countedAmountMinor;
  final int? differenceMinor;
  final DateTime? openedAt;
  final DateTime? closedAt;
  const CashSession({
    this.id,
    required this.cashboxId,
    this.cashboxName,
    this.status = 'open',
    this.openingAmountMinor = 0,
    this.expectedAmountMinor,
    this.countedAmountMinor,
    this.differenceMinor,
    this.openedAt,
    this.closedAt,
  });
  factory CashSession.fromSql(Map<String, Object?> r) => CashSession(
    id: stringOrNull(r['id']),
    cashboxId: r['cashbox_id']?.toString() ?? '',
    cashboxName: stringOrNull(r['cashbox_name']),
    status: r['status']?.toString() ?? 'open',
    openingAmountMinor: intValue(r['opening_amount_minor']),
    expectedAmountMinor:
        r['expected_amount_minor'] == null
            ? null
            : intValue(r['expected_amount_minor']),
    countedAmountMinor:
        r['counted_amount_minor'] == null
            ? null
            : intValue(r['counted_amount_minor']),
    differenceMinor:
        r['difference_minor'] == null ? null : intValue(r['difference_minor']),
    openedAt: parseDate(r['opened_at']),
    closedAt: parseDate(r['closed_at']),
  );
  factory CashSession.fromJson(Map<String, dynamic> r) => CashSession(
    id: stringOrNull(r['id']),
    cashboxId: (r['cashboxId'] ?? r['cashbox_id'])?.toString() ?? '',
    cashboxName: stringOrNull(r['cashboxName'] ?? r['cashbox_name']),
    status: r['status']?.toString() ?? 'open',
    openingAmountMinor: intValue(
      r['openingAmountMinor'] ?? r['opening_amount_minor'],
    ),
    expectedAmountMinor:
        (r['expectedAmountMinor'] ?? r['expected_amount_minor']) == null
            ? null
            : intValue(r['expectedAmountMinor'] ?? r['expected_amount_minor']),
    countedAmountMinor:
        (r['countedAmountMinor'] ?? r['counted_amount_minor']) == null
            ? null
            : intValue(r['countedAmountMinor'] ?? r['counted_amount_minor']),
    differenceMinor:
        (r['differenceMinor'] ?? r['difference_minor']) == null
            ? null
            : intValue(r['differenceMinor'] ?? r['difference_minor']),
    openedAt: parseDate(r['openedAt'] ?? r['opened_at']),
    closedAt: parseDate(r['closedAt'] ?? r['closed_at']),
  );
  Map<String, Object?> toSql() => {
    if (id != null) 'id': id,
    'cashbox_id': cashboxId,
    'status': status,
    'opening_amount_minor': openingAmountMinor,
    'expected_amount_minor': expectedAmountMinor,
    'counted_amount_minor': countedAmountMinor,
    'difference_minor': differenceMinor,
    'opened_at': isoUtc(openedAt),
    'closed_at': isoUtc(closedAt),
  };
  Map<String, dynamic> toJson() => {
    if (id != null) 'id': id,
    'cashboxId': cashboxId,
    'cashboxName': cashboxName,
    'status': status,
    'openingAmountMinor': openingAmountMinor,
    'expectedAmountMinor': expectedAmountMinor,
    'countedAmountMinor': countedAmountMinor,
    'differenceMinor': differenceMinor,
    'openedAt': isoUtc(openedAt),
    'closedAt': isoUtc(closedAt),
  };
  CashSession copyWith({
    Object? id = unset,
    Object? cashboxId = unset,
    Object? cashboxName = unset,
    Object? status = unset,
    Object? openingAmountMinor = unset,
    Object? expectedAmountMinor = unset,
    Object? countedAmountMinor = unset,
    Object? differenceMinor = unset,
    Object? openedAt = unset,
    Object? closedAt = unset,
  }) => CashSession(
    id: id is Unset ? this.id : id as String?,
    cashboxId: cashboxId is Unset ? this.cashboxId : cashboxId as String,
    cashboxName:
        cashboxName is Unset ? this.cashboxName : cashboxName as String?,
    status: status is Unset ? this.status : status as String,
    openingAmountMinor:
        openingAmountMinor is Unset
            ? this.openingAmountMinor
            : openingAmountMinor as int,
    expectedAmountMinor:
        expectedAmountMinor is Unset
            ? this.expectedAmountMinor
            : expectedAmountMinor as int?,
    countedAmountMinor:
        countedAmountMinor is Unset
            ? this.countedAmountMinor
            : countedAmountMinor as int?,
    differenceMinor:
        differenceMinor is Unset
            ? this.differenceMinor
            : differenceMinor as int?,
    openedAt: openedAt is Unset ? this.openedAt : openedAt as DateTime?,
    closedAt: closedAt is Unset ? this.closedAt : closedAt as DateTime?,
  );
}

class PartyLedgerEntry {
  final String? id;
  final String partyId;
  final String entryType;
  final int balanceDeltaMinor;
  final String? referenceType;
  final String? referenceId;
  final String? note;
  final DateTime? occurredAt;
  const PartyLedgerEntry({
    this.id,
    required this.partyId,
    required this.entryType,
    this.balanceDeltaMinor = 0,
    this.referenceType,
    this.referenceId,
    this.note,
    this.occurredAt,
  });
  factory PartyLedgerEntry.fromSql(Map<String, Object?> r) => PartyLedgerEntry(
    id: stringOrNull(r['id']),
    partyId: r['party_id']?.toString() ?? '',
    entryType: r['entry_type']?.toString() ?? '',
    balanceDeltaMinor: intValue(r['balance_delta_minor']),
    referenceType: stringOrNull(r['reference_type']),
    referenceId: stringOrNull(r['reference_id']),
    note: stringOrNull(r['note']),
    occurredAt: parseDate(r['occurred_at']),
  );
  factory PartyLedgerEntry.fromJson(Map<String, dynamic> r) => PartyLedgerEntry(
    id: stringOrNull(r['id']),
    partyId: (r['partyId'] ?? r['party_id'])?.toString() ?? '',
    entryType: (r['entryType'] ?? r['entry_type'])?.toString() ?? '',
    balanceDeltaMinor: intValue(
      r['balanceDeltaMinor'] ?? r['balance_delta_minor'],
    ),
    referenceType: stringOrNull(r['referenceType'] ?? r['reference_type']),
    referenceId: stringOrNull(r['referenceId'] ?? r['reference_id']),
    note: stringOrNull(r['note']),
    occurredAt: parseDate(r['occurredAt'] ?? r['occurred_at']),
  );
  Map<String, Object?> toSql() => {
    if (id != null) 'id': id,
    'party_id': partyId,
    'entry_type': entryType,
    'balance_delta_minor': balanceDeltaMinor,
    'reference_type': referenceType,
    'reference_id': referenceId,
    'note': note,
    'occurred_at': isoUtc(occurredAt),
  };
  Map<String, dynamic> toJson() => {
    if (id != null) 'id': id,
    'partyId': partyId,
    'entryType': entryType,
    'balanceDeltaMinor': balanceDeltaMinor,
    'referenceType': referenceType,
    'referenceId': referenceId,
    'note': note,
    'occurredAt': isoUtc(occurredAt),
  };
  PartyLedgerEntry copyWith({
    Object? id = unset,
    Object? partyId = unset,
    Object? entryType = unset,
    Object? balanceDeltaMinor = unset,
    Object? referenceType = unset,
    Object? referenceId = unset,
    Object? note = unset,
    Object? occurredAt = unset,
  }) => PartyLedgerEntry(
    id: id is Unset ? this.id : id as String?,
    partyId: partyId is Unset ? this.partyId : partyId as String,
    entryType: entryType is Unset ? this.entryType : entryType as String,
    balanceDeltaMinor:
        balanceDeltaMinor is Unset
            ? this.balanceDeltaMinor
            : balanceDeltaMinor as int,
    referenceType:
        referenceType is Unset ? this.referenceType : referenceType as String?,
    referenceId:
        referenceId is Unset ? this.referenceId : referenceId as String?,
    note: note is Unset ? this.note : note as String?,
    occurredAt: occurredAt is Unset ? this.occurredAt : occurredAt as DateTime?,
  );
}

class CashSessionCloseResult {
  final int expectedMinor;
  final int differenceMinor;
  const CashSessionCloseResult({
    required this.expectedMinor,
    required this.differenceMinor,
  });
}

/// Local cash-session policy: the first session receives a counted opening
/// deposit, while every later session carries its opening from the cashbox's
/// actual ledger balance.
class CashSessionStartInfo {
  final bool needsInitialDeposit;
  final int rollingOpeningMinor;
  const CashSessionStartInfo({
    required this.needsInitialDeposit,
    required this.rollingOpeningMinor,
  });
}

/// A compact, user-facing view of a single cashbox. Values are calculated
/// from the immutable cash ledger rather than inferred from document rows.
class CashboxDetails {
  final Cashbox cashbox;
  final int salesInMinor;
  final int purchasesOutMinor;
  final int expensesOutMinor;
  final int advancesNetMinor;
  final List<CashTransaction> transactions;
  const CashboxDetails({
    required this.cashbox,
    required this.salesInMinor,
    required this.purchasesOutMinor,
    required this.expensesOutMinor,
    required this.advancesNetMinor,
    required this.transactions,
  });
}

class PartyAccountSnapshot {
  final int balanceMinor;
  final List<PartyLedgerEntry> ledger;
  const PartyAccountSnapshot({
    required this.balanceMinor,
    required this.ledger,
  });
}
