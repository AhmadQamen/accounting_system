import 'package:accounting_system/core/providers/accounting_providers.dart';
import 'package:accounting_system/core/utils/messges/custom_snackbar.dart';
import 'package:accounting_system/core/domain/money.dart';
import 'package:accounting_system/core/ui/components/premium_ui.dart';
import 'package:accounting_system/features/master_data/models/master_data_models.dart';
import 'package:accounting_system/features/master_data/ui/category_manager_dialog.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

class ProductDetailsDialog extends ConsumerStatefulWidget {
  const ProductDetailsDialog({super.key, required this.product});
  final Product product;

  @override
  ConsumerState<ProductDetailsDialog> createState() =>
      _ProductDetailsDialogState();
}

class _ProductDetailsDialogState extends ConsumerState<ProductDetailsDialog> {
  int revision = 0;

  @override
  Widget build(BuildContext context) {
    final productId = widget.product.id!;
    return Dialog(
      child: ConstrainedBox(
        constraints: const BoxConstraints(maxWidth: 760, maxHeight: 720),
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Row(
                children: [
                  Expanded(
                    child: Text(
                      widget.product.name,
                      style: Theme.of(context).textTheme.headlineSmall,
                    ),
                  ),
                  IconButton(
                    tooltip: 'تعديل بيانات المنتج',
                    onPressed: _editProduct,
                    icon: const Icon(Icons.edit_outlined),
                  ),
                  IconButton(
                    onPressed: () => Navigator.pop(context),
                    icon: const Icon(Icons.close),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              Expanded(
                child: FutureBuilder<ProductDetailsData>(
                  key: ValueKey(revision),
                  future: _load(productId),
                  builder: (context, snapshot) {
                    if (snapshot.connectionState != ConnectionState.done) {
                      return const Center(child: CircularProgressIndicator());
                    }
                    if (snapshot.hasError)
                      return Center(child: Text('${snapshot.error}'));
                    final data = snapshot.data!;
                    final units = data.units;
                    final barcodes = data.barcodes;
                    return ListView(
                      children: [
                        _sectionHeader('الوحدات', () => _addUnit(productId)),
                        ...units.map(
                          (u) => ListTile(
                            leading: Icon(
                              u.isPrimary ? Icons.star : Icons.straighten,
                            ),
                            title: Text(u.name),
                            subtitle: Text(
                              'عامل التحويل: ${u.factor} • سعر البيع: ${_moneyInput(u.salePriceMinor)}',
                            ),
                            trailing: Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                if (u.isPrimary)
                                  const Chip(label: Text('رئيسية')),
                                IconButton(
                                  tooltip: 'تعديل الوحدة والسعر',
                                  onPressed: () => _editUnit(u),
                                  icon: const Icon(Icons.edit_outlined),
                                ),
                              ],
                            ),
                          ),
                        ),
                        const Divider(),
                        _sectionHeader(
                          'الباركود',
                          units.isEmpty ? null : () => _addBarcode(units),
                        ),
                        if (barcodes.isEmpty)
                          const ListTile(title: Text('لا توجد باركودات')),
                        ...barcodes.map(
                          (b) => ListTile(
                            leading: const Icon(Icons.qr_code),
                            title: Text(b.code),
                            subtitle: Text(b.unitName ?? ''),
                          ),
                        ),
                      ],
                    );
                  },
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _sectionHeader(String title, VoidCallback? onAdd) => Padding(
    padding: const EdgeInsets.symmetric(vertical: 8),
    child: Row(
      children: [
        Expanded(
          child: Text(
            title,
            style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 17),
          ),
        ),
        if (onAdd != null)
          IconButton(
            onPressed: onAdd,
            icon: const Icon(Icons.add_circle_outline),
          ),
      ],
    ),
  );

  Future<ProductDetailsData> _load(String productId) async {
    final repo = ref.read(masterDataRepositoryProvider);
    final unitsFuture = repo.listProductUnits(productId);
    final barcodesFuture = repo.listBarcodes(productId);
    return ProductDetailsData(
      units: await unitsFuture,
      barcodes: await barcodesFuture,
      specifications: const [],
    );
  }

  Future<void> _editProduct() async {
    final categories =
        await ref.read(masterDataRepositoryProvider).listCategories();
    if (!mounted) return;
    final name = TextEditingController(text: widget.product.name);
    final min = TextEditingController(
      text: _numberInput(widget.product.minQuantity),
    );
    var categoryId = widget.product.categoryId;
    final ok = await showDialog<bool>(
      context: context,
      builder:
          (dialogContext) => StatefulBuilder(
            builder:
                (dialogContext, setLocal) => AlertDialog(
                  title: const Text('تعديل المنتج'),
                  content: SizedBox(
                    width: responsiveDialogWidth(context, 420),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        TextField(
                          controller: name,
                          decoration: const InputDecoration(
                            labelText: 'اسم المنتج',
                          ),
                        ),
                        const SizedBox(height: 9),
                        DropdownButtonFormField<String?>(
                          initialValue: categoryId,
                          items: [
                            const DropdownMenuItem<String?>(
                              value: null,
                              child: Text('بدون تصنيف'),
                            ),
                            ...categories.map(
                              (category) => DropdownMenuItem<String?>(
                                value: category.id,
                                child: Text(category.name),
                              ),
                            ),
                          ],
                          onChanged:
                              (value) => setLocal(() => categoryId = value),
                          decoration: const InputDecoration(
                            labelText: 'التصنيف',
                          ),
                        ),
                        const SizedBox(height: 9),
                        TextField(
                          controller: min,
                          keyboardType: const TextInputType.numberWithOptions(
                            decimal: true,
                          ),
                          decoration: const InputDecoration(
                            labelText: 'الحد الأدنى للمخزون',
                          ),
                        ),
                        Align(
                          alignment: AlignmentDirectional.centerStart,
                          child: TextButton.icon(
                            onPressed:
                                () => showDialog<void>(
                                  context: dialogContext,
                                  builder: (_) => const CategoryManagerDialog(),
                                ),
                            icon: const Icon(Icons.add_rounded, size: 16),
                            label: const Text('إدارة التصنيفات'),
                          ),
                        ),
                      ],
                    ),
                  ),
                  actions: [
                    TextButton(
                      onPressed: () => Navigator.pop(dialogContext, false),
                      child: const Text('إلغاء'),
                    ),
                    FilledButton(
                      onPressed: () => Navigator.pop(dialogContext, true),
                      child: const Text('حفظ التعديل'),
                    ),
                  ],
                ),
          ),
    );
    if (ok == true) {
      try {
        await ref
            .read(masterDataRepositoryProvider)
            .updateProduct(
              id: widget.product.id!,
              name: name.text,
              categoryId: categoryId,
              minQuantity: double.tryParse(min.text.trim()) ?? -1,
            );
        ref.read(dataRevisionProvider.notifier).state++;
        setState(() => revision++);
      } catch (error) {
        if (mounted) CustomSnackBar.showErrorSnackbar('$error');
      }
    }
    name.dispose();
    min.dispose();
  }

  Future<void> _addUnit(String productId) =>
      _showUnitEditor(productId: productId);

  Future<void> _editUnit(ProductUnit unit) =>
      _showUnitEditor(productId: unit.productId, existing: unit);

  Future<void> _showUnitEditor({
    required String productId,
    ProductUnit? existing,
  }) async {
    final name = TextEditingController(text: existing?.name ?? '');
    final factor = TextEditingController(
      text: existing == null ? '1' : _numberInput(existing.factor),
    );
    final salePrice = TextEditingController(
      text: _moneyInput(existing?.salePriceMinor ?? 0),
    );
    var primary = existing?.isPrimary ?? false;
    final ok = await showDialog<bool>(
      context: context,
      builder:
          (dialogContext) => StatefulBuilder(
            builder:
                (dialogContext, setLocal) => AlertDialog(
                  title: Text(existing == null ? 'إضافة وحدة' : 'تعديل الوحدة'),
                  content: SizedBox(
                    width: responsiveDialogWidth(context, 420),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        TextField(
                          controller: name,
                          decoration: const InputDecoration(
                            labelText: 'اسم الوحدة',
                          ),
                        ),
                        const SizedBox(height: 8),
                        TextField(
                          controller: factor,
                          keyboardType: TextInputType.number,
                          decoration: const InputDecoration(
                            labelText: 'عامل التحويل للوحدة الرئيسية',
                          ),
                        ),
                        const SizedBox(height: 8),
                        TextField(
                          controller: salePrice,
                          keyboardType: const TextInputType.numberWithOptions(
                            decimal: true,
                          ),
                          decoration: const InputDecoration(
                            labelText: 'سعر البيع',
                          ),
                        ),
                        CheckboxListTile(
                          contentPadding: EdgeInsets.zero,
                          value: primary,
                          onChanged:
                              existing?.isPrimary == true
                                  ? null
                                  : (v) => setLocal(() => primary = v ?? false),
                          title: const Text('اجعلها الوحدة الرئيسية'),
                        ),
                      ],
                    ),
                  ),
                  actions: [
                    TextButton(
                      onPressed: () => Navigator.pop(dialogContext, false),
                      child: const Text('إلغاء'),
                    ),
                    FilledButton(
                      onPressed: () => Navigator.pop(dialogContext, true),
                      child: const Text('حفظ'),
                    ),
                  ],
                ),
          ),
    );
    if (ok == true) {
      try {
        await ref
            .read(masterDataRepositoryProvider)
            .saveProductUnit(
              productId: productId,
              id: existing?.id,
              name: name.text,
              factor: double.parse(factor.text),
              salePriceMinor: Money.fromMajor(salePrice.text),
              isPrimary: primary,
            );
        setState(() => revision++);
        ref.read(dataRevisionProvider.notifier).state++;
      } catch (e) {
        if (mounted) CustomSnackBar.showErrorSnackbar('$e');
      }
    }
    name.dispose();
    factor.dispose();
    salePrice.dispose();
  }

  String _moneyInput(int minor) {
    final value = Money(minor).major.toStringAsFixed(2);
    return value.replaceFirst(RegExp(r'\.?0+$'), '');
  }

  String _numberInput(double value) =>
      value == value.truncateToDouble()
          ? value.toStringAsFixed(0)
          : value.toString();

  Future<void> _addBarcode(List<ProductUnit> units) async {
    var unitId = units.first.id!;
    final code = TextEditingController();
    final ok = await showDialog<bool>(
      context: context,
      builder:
          (dialogContext) => StatefulBuilder(
            builder:
                (dialogContext, setLocal) => AlertDialog(
                  title: const Text('إضافة باركود'),
                  content: SizedBox(
                    width: responsiveDialogWidth(context, 420),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        DropdownButtonFormField<String>(
                          value: unitId,
                          items:
                              units
                                  .map(
                                    (u) => DropdownMenuItem(
                                      value: u.id!,
                                      child: Text(u.name),
                                    ),
                                  )
                                  .toList(),
                          onChanged: (v) {
                            if (v != null) setLocal(() => unitId = v);
                          },
                          decoration: const InputDecoration(
                            labelText: 'الوحدة',
                          ),
                        ),
                        const SizedBox(height: 8),
                        TextField(
                          controller: code,
                          decoration: const InputDecoration(
                            labelText: 'الباركود',
                          ),
                        ),
                      ],
                    ),
                  ),
                  actions: [
                    TextButton(
                      onPressed: () => Navigator.pop(dialogContext, false),
                      child: const Text('إلغاء'),
                    ),
                    FilledButton(
                      onPressed: () => Navigator.pop(dialogContext, true),
                      child: const Text('حفظ'),
                    ),
                  ],
                ),
          ),
    );
    if (ok == true) {
      try {
        await ref
            .read(masterDataRepositoryProvider)
            .addBarcode(productUnitId: unitId, code: code.text);
        setState(() => revision++);
        ref.read(dataRevisionProvider.notifier).state++;
      } catch (e) {
        if (mounted) CustomSnackBar.showErrorSnackbar('$e');
      }
    }
    code.dispose();
  }
}
